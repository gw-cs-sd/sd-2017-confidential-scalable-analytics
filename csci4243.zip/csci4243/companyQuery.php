<?php 

	require_once('mysqli_connect.php');

	$searchString = $_GET['company'];

	$companies = mysqli_query($dbConnection, "SELECT * FROM companies");
	$companiesArray = array();
	$suggestion = "";

	if($companies && mysqli_num_rows($companies)){

		while($row = mysqli_fetch_array($companies)){
			$companiesArray[] = $row;
		}

		if($searchString != ""){
			$stringLength = strlen($searchString);
			foreach($companiesArray as $company){
				$sameLengthString = substr($company['company_name'], 0, $stringLength);
				if(strcasecmp($searchString, $sameLengthString) === 0){
					$suggestion .= "<a id='companySuggestionLink' onclick='selectCompanySuggestion(\"" . $company['company_name'] . "\")'>" . 
					$company['company_name'] . "</a>";
				}
			}
		}

		if($suggestion != ""){
			echo $suggestion;
		}
	}
?>