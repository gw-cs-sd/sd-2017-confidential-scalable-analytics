<?php
	
	session_start();
	$userId = $_SESSION['userId'];

	if(isset($_POST['verifier']) && isset($_POST['threshold']) && isset($_POST['bankNames'])){
		$verifier = $_POST['verifier'];
		$threshold = $_POST['threshold'];
		$numberOfBanks = count(explode(",", $_POST['bankNames']));

		$jnlpFile = fopen("paillierApp.jnlp", "w");

		$jnlpContents =	'<?xml version="1.0" encoding="utf-8"?>
						<jnlp spec="1.0+" codebase="http://localhost/csci4243/" href="paillierApp.jnlp">
						     <information>
						          <title>Paillier Encrypter</title>
						          <vendor>eVERIFY</vendor>
						          <homepage href="http://localhost/csci4243/" />
						     </information>
						     <security>
						          <all-permissions/>
						     </security>
						     <resources>
						          <j2se version="1.7+" />
						          <jar href="paillierEncrypter.jar" />
						     </resources>
						     <application-desc main-class="paillierPackage.SwingApp">
						     	  <argument>' . strval($threshold) . '</argument>
							      <argument>' . strval($numberOfBanks) . '</argument>
							      <argument>' . $verifier . '</argument>
						          <argument>' . strval($userId) . '</argument>
						     </application-desc>
						     <update check="always" policy="prompt-update" />
						</jnlp>';

		fwrite($jnlpFile, $jnlpContents);
		fclose($jnlpFile);
		header('Location: paillierApp.jnlp');
	} else {
		header('Location: addVerification.php');
	}

?>

